(function($) {
	$(document).ready(function() {

		// Color picker
		$('.jgtstork-color-field').wpColorPicker();
		
	});
})(jQuery);