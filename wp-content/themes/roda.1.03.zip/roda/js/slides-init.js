

//Superslides init
jQuery(function($) {
	$('#slides').superslides({
		play: 5000,
		animation: 'fade',
		pagination: false
	});
});